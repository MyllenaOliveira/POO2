package controlevendas;


import java.io.File;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mylle
 */
public class ManipulaArquivo {
       File produtos = new File("C:\\Users\\mylle\\Desktop\\Apostilas do curso\\POOII/Estoque/produtos.txt");
       File funcionarios = new File("C:\\Users\\mylle\\Desktop\\Apostilas do curso\\POOII/Estoque/funcionarios.txt");

}
