package controlevendas;


public class Cliente extends Pessoa{
  
}
